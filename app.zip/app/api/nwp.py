from fastapi import APIRouter, Query
from app.services.nwp_service import get_nwp_forecast

router = APIRouter(prefix="/nwp", tags=["NWP"])


@router.get("/forecast")
def nwp_forecast(
    latitude: float = Query(...),
    longitude: float = Query(...),
    model: str = Query("gfs")
):
    return get_nwp_forecast(
        latitude=latitude,
        longitude=longitude,
        model=model
    )