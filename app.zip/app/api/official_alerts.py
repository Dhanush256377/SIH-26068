from fastapi import APIRouter, Query

from app.services.official_alert_service import get_official_alerts


router = APIRouter(
    prefix="/official-alerts",
    tags=["Official Alerts"]
)


@router.get("/")
def official_alerts(
    identifier: str = Query(...)
):

    return get_official_alerts(identifier)