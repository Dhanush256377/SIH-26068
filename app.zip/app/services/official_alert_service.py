import requests
import xml.etree.ElementTree as ET

SACHET_URL = "https://sachet.ndma.gov.in/cap_public_website/FetchXMLFile"

_cached_xml = None
_cached_etag = None


def get_text(root, tag):
    element = root.find(".//" + tag)

    if element is not None and element.text:
        return element.text.strip()

    return ""


def parse_alert(xml_text):

    if not xml_text:
        return None

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return None

    info = root.find(".//info")

    if info is None:
        return None

    alert = {
        "identifier": get_text(root, "identifier"),
        "sender": get_text(root, "sender"),
        "sent": get_text(root, "sent"),
        "status": get_text(root, "status"),
        "msg_type": get_text(root, "msgType"),
        "event": get_text(info, "event"),
        "headline": get_text(info, "headline"),
        "description": get_text(info, "description"),
        "instruction": get_text(info, "instruction"),
        "severity": get_text(info, "severity"),
        "urgency": get_text(info, "urgency"),
        "certainty": get_text(info, "certainty"),
        "effective": get_text(info, "effective"),
        "onset": get_text(info, "onset"),
        "expires": get_text(info, "expires"),
        "area": []
    }

    for area in info.findall(".//area"):

        area_data = {
            "area_desc": get_text(area, "areaDesc"),
            "polygon": get_text(area, "polygon"),
            "circle": get_text(area, "circle")
        }

        alert["area"].append(area_data)

    return alert


def get_official_alerts(identifier):

    global _cached_xml
    global _cached_etag

    headers = {}

    if _cached_etag:
        headers["If-None-Match"] = _cached_etag

    params = {
        "identifier": identifier
    }

    try:

        response = requests.get(
            SACHET_URL,
            params=params,
            headers=headers,
            timeout=15
        )

        if response.status_code == 304:

            parsed_alert = parse_alert(_cached_xml)

            return {
                "success": True,
                "status": "not_modified",
                "source": "NDMA SACHET",
                "message": "No new official alert data.",
                "alert": parsed_alert
            }

        response.raise_for_status()

        _cached_xml = response.text
        _cached_etag = response.headers.get("ETag")

        parsed_alert = parse_alert(_cached_xml)

        if parsed_alert is None:

            return {
                "success": False,
                "source": "NDMA SACHET",
                "message": "Official alert data could not be parsed."
            }

        return {
            "success": True,
            "status": "updated",
            "source": "NDMA SACHET",
            "etag": _cached_etag,
            "alert": parsed_alert
        }

    except requests.RequestException as e:

        return {
            "success": False,
            "source": "NDMA SACHET",
            "message": "Unable to retrieve official alert data.",
            "error": str(e)
        }