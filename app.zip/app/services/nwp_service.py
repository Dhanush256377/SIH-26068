import requests


def get_nwp_forecast(latitude, longitude, model="gfs"):
    if model.lower() != "gfs":
        return {
            "success": False,
            "message": "Currently GFS is available. WRF support can be connected when a WRF data source is configured."
        }

    url = "https://api.open-meteo.com/v1/forecast"

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": ",".join([
            "temperature_2m",
            "relative_humidity_2m",
            "precipitation",
            "rain",
            "wind_speed_10m",
            "wind_direction_10m",
            "surface_pressure",
            "cloud_cover"
        ]),
        "forecast_days": 3,
        "models": "gfs_seamless",
        "timezone": "auto"
    }

    try:
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()

        data = response.json()

        return {
            "success": True,
            "model": "GFS",
            "latitude": latitude,
            "longitude": longitude,
            "timezone": data.get("timezone"),
            "hourly": data.get("hourly", {})
        }

    except requests.RequestException as e:
        return {
            "success": False,
            "message": "Unable to retrieve GFS forecast data.",
            "error": str(e)
        }